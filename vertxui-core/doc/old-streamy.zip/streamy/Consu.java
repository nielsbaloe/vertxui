package live.connector.vertxui.streamy;

public interface Consu<T> {
	void accept(T t);
}