package live.connector.vertxui.streamy;

public interface BiOp<T> extends BiFunc<T, T, T> {
}